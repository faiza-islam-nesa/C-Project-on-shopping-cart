#include<iostream>
#include<string>
#include<fstream>
#include<sstream>


using namespace std;


class ShoppingCart;
class Product;

const int MAX_CART = 10;
int current_carts = 0;

class Product
{
public:
    int id;          // product id
    string name;     // product name
    double price;    // price of product
    int stock;       // availability

    // Parameterized constructor
    Product(int pID, string p_name, double p_price, int p_stock)
    {
        id = pID;
        name = p_name;
        price = p_price;
        stock = p_stock;
    }
    Product()
    {
        id=0;
        name= " ";
        price=0.0;
        stock=0;

    }

    void display()
    {
        cout << id << ". " << name << " - $" << price << " (Stock: " << stock << ")\n";
    }
};

class ShoppingCart
{
public:
    Product cart[100];
    int quantities[100];

    int itemCount = 0;
    int totalAmount = 0;

    void addProduct(Product& product, int quantity)
    {
        if (product.stock < quantity) {
            cout << "Not enough stock available for " << product.name << ".\n";
            return;
        }

        for (int i = 0; i < itemCount; ++i)
        {
            if (cart[i].id == product.id)
            {
                quantities[i] += quantity;
                product.stock -= quantity;
                cout << quantity << " x " << product.name << " added to cart.\n";
                itemCount += 1;
                return;
            }
        }

        cart[itemCount] = product;
        quantities[itemCount] = quantity;
        product.stock -= quantity;
        itemCount+=1;
        cout << quantity << " x " << product.name << " added to cart.\n";
    }

    void removeProduct(int productId, Product products[], int productCount)
    {
        for (int i = 0; i < itemCount; ++i)
        {
            if (cart[i].id == productId)
            {
                for (int j = 0; j < productCount; ++j)
                {
                    if (products[j].id == productId)
                    {
                        products[j].stock += quantities[i];
                        break;
                    }
                }

                for (int j = i; j < itemCount - 1; ++j)
                {
                    cart[j] = cart[j + 1];
                    quantities[j] = quantities[j + 1];
                }

                --itemCount;
                cout << "Product removed from cart and stock updated.\n";
                return;
            }
        }

        cout << "Product not found in cart.\n";
    }

    void viewCart()
    {
        if (itemCount == 0)
        {
            cout << "Your cart is empty.\n";
            return;
        }

        cout << "Shopping Cart:\n";
        double total = 0;

        for (int i = 0; i < itemCount; ++i)
        {
            cout << cart[i].name << " x " << quantities[i]
                 << " - $" << cart[i].price * quantities[i] << "\n";
            total += cart[i].price * quantities[i];
        }

        cout << "Total: $" << total << "\n";
    }

    int getTotal()
    {
        int total = 0;

        for (int i = 0; i < itemCount; ++i)
        {
            total += cart[i].price * quantities[i];
        }

        return total;
    }

    void clearCart(Product products[], int productCount)
    {
        for (int i = 0; i < itemCount; ++i)
        {
            for (int j = 0; j < productCount; ++j)
            {
                if (products[j].id == cart[i].id)
                {
                    products[j].stock += quantities[i];
                    break;
                }
            }
        }

        itemCount = 0;
    }

    void saveToFile(ofstream &file)
    {
        file << itemCount << " " << max(totalAmount, getTotal()) << " ";
        for(int i = 0;i < itemCount;i++)
        {
            file << cart[i].name << " " << quantities[i] << " ";
        }
        file << '\n';
    }


    void loadFromFile(string line)
    {

        string words[1002];
        string word;
        for(int i = 0;i < 1000;i++)
        {
            words[i] = "NULL_VALUE";
        }

        istringstream iss(line);
        int i = 0, j = 0;

        while(iss >> word)
        {
            words[i] = word;
            i++;
        }

        itemCount = stoi(words[0]);
        totalAmount = stoi(words[1]);
        cout << totalAmount << endl;
        i = 2, j =0;
        while(words[i] != "NULL_VALUE")
        {
            cart[j].name = words[i];
            quantities[j] = stoi(words[i+1]);
            j++;
            i += 2;
        }

    }
};


ShoppingCart allShoppingCarts[MAX_CART];

void save()
{
    ofstream file("records.txt");
    for(int i = 0;i <= current_carts;i++)
    {
        allShoppingCarts[i].saveToFile(file);
    }
    file.close();
}

void load()
{
    ifstream file("records.txt");
    if(file.is_open())
    {
        string line;
        while(getline(file, line))
        {
            allShoppingCarts[current_carts].loadFromFile(line);
            current_carts += 1;
        }
    }
}

void loadData(){
    int tr = 1;

    for(int i = 0;i < current_carts;i++)
    {
        cout << "\n\nTransaction " << tr << ": \n" << endl;
        cout << "Total: " << allShoppingCarts[i].totalAmount << endl;
        cout << "Total Items: " << allShoppingCarts[i].itemCount << endl;

        for(int j = 0;j < allShoppingCarts[i].itemCount;j++)
        {
            cout << allShoppingCarts[i].cart[j].name << "  " << allShoppingCarts[i].quantities[j] << endl;
        }

        tr++;
    }
}
class OnlineShoppingSystem
{
private:
    Product products[5];
    ShoppingCart cart;

    void showProducts()
    {
        cout << "\nAvailable Products:\n";

        for (int i = 0; i < 5; ++i)
        {
            products[i].display();
        }
    }

    void searchProduct(const string& query)
    {
        cout << "\nSearch Results for '" << query << "':\n";

        for (int i = 0; i < 5; ++i)
        {
            if (products[i].name == query)
            {
                products[i].display();
            }
        }
    }

    void processPayment()
    {
        double total = cart.getTotal();

        if (total == 0)
        {
            cout << "Your cart is empty. Payment cannot be processed.\n";
            return;
        }

        cout << "\nProcessing payment of $" << total << "...\n";
        cout << "Payment successful!\n";
        allShoppingCarts[current_carts] = cart;
        save();
        current_carts += 1;
        cart.clearCart(products, 5);
    }

    void trackOrder()
    {
        cout << "\nOrder Status: Processing -> Shipped -> Delivered\n";
    }

    void recommendProducts()
    {
        cout << "\nPersonalized Recommendations:\n";

        for (int i = 0; i < 5; ++i)
        {
            if (products[i].stock > 0)
            {
                products[i].display();
            }
        }
    }

public:
    OnlineShoppingSystem()
    {
        products[0] = Product(1, "Laptop", 1500.00, 20);
        products[1] = Product(2, "Power Bank", 300.00, 10);
        products[2] = Product(3, "Headphones", 150.00, 40);
        products[3] = Product(4, "Pendrive", 100.00, 15);
        products[4] = Product(5, "Mouse", 30.00, 40);
    }

    void run()
    {
        int choice;

        do {
            cout << "\n--- Online Shopping System ---\n";
            cout << "1. Browse Products\n";
            cout << "2. Search Product\n";
            cout << "3. View Cart\n";
            cout << "4. Add to Cart\n";
            cout << "5. Remove from Cart\n";
            cout << "6. Payment Process\n";
            cout << "7. Track Order\n";
            cout << "8. Get Recommendations\n";
            cout << "9. Get Previous Transactions\n";
            cout << "10. Exit\n";
            cout << "Enter your choice: ";
            cin >> choice;

            if (choice == 1) {
                showProducts();
            } else if (choice == 2) {
                string query;
                cout << "Enter product name to search: ";
                cin.ignore();
                getline(cin, query);
                searchProduct(query);
            } else if (choice == 3) {
                cart.viewCart();
            } else if (choice == 4) {
                int productId, quantity;
                showProducts();
                cout << "Enter product ID to add: ";
                cin >> productId;
                cout << "Enter quantity: ";
                cin >> quantity;
                cart.addProduct(products[productId - 1], quantity);
            } else if (choice == 5) {
                int productId;
                cout << "Enter product ID to remove: ";
                cin >> productId;
                cart.removeProduct(productId, products, 5);
            } else if (choice == 6) {
                processPayment();
            } else if (choice == 7) {
                trackOrder();
            } else if (choice == 8) {
                recommendProducts();
            } else if (choice == 9) {
                loadData();
            } else if(choice == 10) {
                cout << "Exiting the system. Thank you!\n";
                exit(0);
            } else {
                cout << "Invalid choice. Try again.\n";
            }
        } while (choice != 10);
    }
};


int main()
{
    load();
    OnlineShoppingSystem system;
    system.run();
    return 0;
}
